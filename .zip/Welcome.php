<!DOCTYPE html>
<html>
<head>
<title>StoreCollection</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<style>
* {
  box-sizing: border-box;
}
#j1.jumbotron{
  background-color:#6D7993;
  /*background-image: url('jumbo.jpg');*/
  background-size: contain ;
  background-position: center;
  background-repeat: no-repeat;
  height: 150px;
  background-size: cover
}

div::after{

  content: "";
  background-color: #ab5e32;
    opacity: 0.1;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;

}
body {
  
  padding: 20px;
  font-family: Arial;
}
html {
  height: 100%;
}

.bg {
 
  background-image: url("bg.jpg");
  height: 100%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.buttonR {background-color: #f44336;} /* Red */ 

.box
{
  width: 900px;
  height: 400px;
  padding: 20px;
  margin: 10px auto;
  box-shadow: 0px 0px 10px 2px grey;
  border: 5px solid grey;
  background-image: url(Rit3.jpg);
  background-size: cover; 
}


</style>

<script language="javascript">
    function totalBal()
    {
        var exit = parseInt(document.getElementById("ExitBal").value);
        var add = parseInt(document.getElementById("AddBal").value);
        var ansT = document.getElementById("totalB");
        ansT.value = exit + add;
    }
    
    function RTBal()
    {
    	var total = parseInt(document.getElementById("totalB").value);
    	var Amount = parseInt(document.getElementById("amount").value);
    	var Otf = parseInt(document.getElementById("otf").value);
    	var ansRT = document.getElementById("rtbal");
        ansRT.value = total - Amount + Otf; 
    }
</script>
</head>

<body class="bg">
<div class="jumbotron text-left", id="j1" style="margin-bottom:0">
  <h1>Airtel Store</h1>
  <p>Collection Of Easy Recharge,FSE Distributers,Bank Distributers</p> 
</div>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="Welcome.php">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Home &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="navbar-brand " href="easyRecharge.php">&nbsp&nbsp&nbsp&nbsp Easy Recharge &nbsp&nbsp&nbsp&nbsp</a>
      </li>
      <li class="nav-item">
        <a class="navbar-brand" href="FSE-Dis.php"> &nbsp&nbsp&nbsp&nbsp FSE Distributor &nbsp&nbsp&nbsp&nbsp</a>
      </li>
          <li class="nav-item">
        <a class="navbar-brand" href="BankCollect.php"> &nbsp&nbsp&nbsp&nbsp Bank Distributor &nbsp&nbsp&nbsp&nbsp</a>
      </li>
    </ul><li>
        
  </div>  
</nav>

<br><br>
<div class="container box">
  <form action="push.php" method="post">
  
    <div class="row">
      <h2></h2>
    </div>
    <br>
    <div class="row">
      <!--<div class="col-sm-2">-->
      <!--  &nbsp&nbsp&nbsp&nbsp<label for="date"><b>Date</b></label>&nbsp&nbsp&nbsp-->
      <!--  <input type="date"  name="datesim" required>&nbsp&nbsp&nbsp-->
      <!--</div>-->

      <!--<div class="col-sm-10">-->
      <!--  <div class="row">-->
      <!--    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<label><b>Easy Recharge Openning Balance</b></label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp-->
      <!--    <input type="text"  name="newcno" >&nbsp-->
      <!--  </div>-->
      <!--  <br>-->
      <!--  <div class="row">-->
      <!--   &nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<label><b>FSE Distributer Openning Balance</b></label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp-->
      <!--    <input type="text"  name="newcno" >&nbsp-->
      <!--  </div>-->
      <!--  <br>-->
      <!--  <div class="row">-->
      <!--   &nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<label><b>Bank Distribution Balance</b></label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp-->
      <!--    <input type="text"  name="newcno" >&nbsp-->
      <!--  </div>-->
    </div>
    <br>
    <br><br>
    
<!-----------------_________________________-->

    <div class="Row">
    <div class="col-sm-12">
      <div class="row"><br>
        &nbsp&nbsp&nbsp&nbsp
        <button type="submit" name="export_excel1" class="btn btn-link" style="color:#34073d" formaction="/Exceldownload.php"><b>Easy recharge download</b></button>
        &nbsp&nbsp
        <button type="submit" name="export_excel2" class="btn btn-link" style="color:#34073d" formaction="/Exceldownload.php"><b>Sim card download</b></button>
        &nbsp&nbsp
        <button type="submit" name="export_excel3" class="btn btn-link" style="color:#34073d" formaction="/Exceldownload.php"><b>Sim swap download</b></button>
        
        &nbsp&nbsp
        <button type="submit" name="export_excel4" class="btn btn-link" style="color:#34073d" formaction="/Exceldownload.php"><b>Airtel payment download</b></button>
        &nbsp&nbsp
    </div></br></br>
      <div class="row">
          &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <button type="submit" name="export_excel5" class="btn btn-link" style="color:#34073d" formaction="/Exceldownload.php"><b>FSE Distributor download</b></button>&nbsp&nbsp&nbsp&nbsp
      
      </div><br><br>
      <div class="row">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <button type="submit" name="export_excel6" class="btn btn-link" style="color: #34073d" formaction="/Exceldownload.php"><b>Bank Collection download</b></button>&nbsp&nbsp&nbsp
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <button type="submit" name="export_excel7" class="btn btn-link" style="color: #34073d" formaction="/Exceldownload.php"><b>Bank details download</b></button>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <button type="submit" name="export_excel8"  class="btn btn-link" style="color:#34073d" formaction="/Exceldownload.php"><b>Bank Payment download</b></button>
      </div>
    </div>
 </form>
</div>

    
    

</body>
</html>