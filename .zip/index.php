<!DOCTYPE html>
<html>
<head>
   <title>StoreCollection</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<style>
* {
  box-sizing: border-box;
}

#j1.jumbotron{

  background-image: url("jumbo.jpg");
  background-size: contain ;
  background-position: center;
  background-repeat: no-repeat;
 
height: 20px;

  /* Full height */
  height: 100%; 
  background-size: cover;
  margin: 0;
  height: 200px;
}

div::after{

  content: "";
  background-color: #ab5e32;

  
    opacity: 0.1;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;

}
body {
  background-color: #f1f1f1;
  

  background-image: url("img.jpg");
  padding: 20px;
  font-family: Arial;
  background-origin: content-box;
  opacity: 1;
  background-size:cover;
}
    /* Make the image fully responsive */
  .carousel-inner img {
      width: 100%;
      height: 100%;
  }
  </style>
</>
</head>
<body>





 
<div class="jumbotron text-left", id="j1" style="margin-bottom:0">
  <h1 >Airtel Store</h1>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
  <p><b>Collection Of Easy Recharge,FSE Distributers,Bank Distributers</b></p> 
</div>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Home &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="navbar-brand " href="login.php">&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp Login &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
      </li>
      <li class="nav-item">
        <a class="navbar-brand" href="contact.php">&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp Contct us &nbsp&nbsp&nbsp&nbsp</a>
      </li>
          <li class="nav-item">
        <a class="navbar-brand" href="technicalhelp.php">&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbspTechnical help &nbsp&nbsp&nbsp&nbsp</a>
      </li>
     </ul><li>
  </div>  
</nav>


  
  <div class="row">
    <div class="col-sm-2">
      
    </div>
    <div class="col-sm-8">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp



<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="la.jpg" alt="Los Angeles" width="1100" height="500">
    </div>
    <div class="carousel-item">
      <img src="chicago.jpg" alt="Chicago" width="1100" height="500">
    </div>
    <div class="carousel-item">
      <img src="ny.jpg" alt="New York" width="1100" height="500">
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
     </div>
    <div class="col-sm-2">
      
    </div>
  </div>
</div>
</body>
</html>