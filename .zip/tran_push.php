<?php 
session_start(); 
$con=mysqli_connect('localhost','id12710932_kailash1','kailash');
mysqli_select_db($con, "id12710932_db1");


if (isset($_POST['submit101'])) 
{
    $date = $_POST['date'];
    $new_number1 = $_POST['new_number1'];
    $new_name1 = $_POST['new_name1'];
    $new_number2 = $_POST['new_number2'];
    $new_name2 = $_POST['new_name2'];
    $new_number3 = $_POST['new_number3'];
    $new_name3 = $_POST['new_name3'];
    $new_number4 = $_POST['new_number4'];
    $new_name4 = $_POST['new_name4'];

    
  
  $sql = "insert into simcard(dt,new_number,new_name)
  values('$date','$new_number1','$new_name1'),
  ('$date','$new_number2','$new_name2'),
    ('$date','$new_number3','$new_name3'),
      ('$date','$new_number4','$new_name4')";

  mysqli_query($con,$sql);
  header('location:new_sim.php') ; 
}



if (isset($_POST['submit102'])) {
  $date = $_POST['date'];
  $number1 = $_POST['number1'];
    $name1 = $_POST['name1'];
    $number2 = $_POST['number2'];
    $name2 = $_POST['name2'];
    $number3 = $_POST['number3'];
    $name3 = $_POST['name3'];
    $number4 = $_POST['number4'];
    $name4 = $_POST['name4'];

    
  
  $sql = "insert into mnpcard(ndt,mnp_number,mnp_name)
  values('$date','$number1','$name1'),
  ('$date','$number2','$name2'),
    ('$date','$number3','$name3'),
      ('$date','$number4','$name4')";

  mysqli_query($con,$sql);
  header('location:mnp.php') ; 
}

if (isset($_POST['submit103'])) {
    $date = $_POST['date'];
    $number1 = $_POST['number1'];
    $ammount1 = $_POST['ammount1'];
    $number2 = $_POST['number2'];
    $ammount2 = $_POST['ammount2'];
    $number3 = $_POST['number3'];
    $ammount3 = $_POST['ammount3'];
    $number4 = $_POST['number4'];
    $ammount4 = $_POST['ammount4'];

$sql = "insert into simswap(dt,swap_number,swap_amount)
        values('$date','$number1','$ammount1'),
  (             ('$date','$number2','$ammount2'),
                ('$date','$number3','$ammount3'),
                ('$date','$number4','$ammount4')";

  mysqli_query($con,$sql);
  header('location:sim_swap.php') ; 
}


if (isset($_POST['submit104'])) {
  $date = $_POST['date'];
  $number1 = $_POST['number1'];
    $ammount1 = $_POST['ammount1'];
    $number2 = $_POST['number2'];
    $ammount2 = $_POST['ammount2'];
    $number3 = $_POST['number3'];
    $ammount3 = $_POST['ammount3'];
    $number4 = $_POST['number4'];
    $ammount4 = $_POST['ammount4'];

    
  
  $sql = "insert into fourg(dt,fourg_number,fourg_amount)
  values('$date','$number1','$ammount1'),
  ('$date','$number2','$ammount2'),
    ('$date','$number3','$ammount3'),
      ('$date','$number4','$ammount4')";

  mysqli_query($con,$sql);
  header('location:4G.php') ; 
}



if (isset($_POST['submit'])) {
  $date = $_POST['date'];
  $number1 = $_POST['number1'];
    $ammount1 = $_POST['ammount1'];
    $number2 = $_POST['number2'];
    $ammount2 = $_POST['ammount2'];
    $number3 = $_POST['number3'];
    $ammount3 = $_POST['ammount3'];
    $number4 = $_POST['number4'];
    $ammount4 = $_POST['ammount4'];

    $sql = "insert into bank1(date,number,amount)
            values('$date','$number1','$ammount1'),
            ('$date','$number2','$ammount2'),
            ('$date','$number3','$ammount3'),
            ('$date','$number4','$ammount4')";

  mysqli_query($con,$sql);
  header('location:cash_transfer.php') ; 
}






if (isset($_POST['submit2'])) {
  $date = $_POST['date'];
  $number1 = $_POST['number1'];
    $remark1 = $_POST['remark1'];
    $number2 = $_POST['number2'];
    $remark2 = $_POST['remark2'];
    $number3 = $_POST['number3'];
    $remark3 = $_POST['remark3'];
    $number4 = $_POST['number4'];
    $remark4 = $_POST['remark4'];

    
  
  $sql = "insert into neft(date,number,remark)
  values('$date','$number1','$remark1'),
  ('$date','$number2','$remark2'),
    ('$date','$number3','$remark3'),
      ('$date','$number4','$remark4')";

  mysqli_query($con,$sql);
  header('location:NEFT.php') ; 

}

if (isset($_POST['submit4'])) {
  $date = $_POST['date'];
  $ammount1 = $_POST['ammount1'];
    $reason1 = $_POST['reason1'];
    $ammount2 = $_POST['ammount2'];
    $reason2 = $_POST['reason2'];
    $ammount3 = $_POST['ammount3'];
    $reason3 = $_POST['reason3'];
    $ammount4 = $_POST['ammount4'];
    $reason4 = $_POST['reason4'];

    
  
  $sql = "insert into expense(dt,ex_amount,ex_remark)
  values('$date','$ammount1','$reason1'),
  ('$date','$ammount2','$reason2'),
    ('$date','$ammount3','$reason3'),
      ('$date','$ammount4','$reason4')";

  mysqli_query($con,$sql);
  header('location:expenses.php') ; 
}


if (isset($_POST['submit5'])) {
  $date = $_POST['date'];
  $ammount1 = $_POST['ammount1'];
    $reason1 = $_POST['reason1'];
    $ammount2 = $_POST['ammount2'];
    $reason2 = $_POST['reason2'];
    $ammount3 = $_POST['ammount3'];
    $reason3 = $_POST['reason3'];
    $ammount4 = $_POST['ammount4'];
    $reason4 = $_POST['reason4'];

    $sql = "insert into ost(dt,ost_number,ost_amount) values('$date','$ammount1','$reason1')";
    $sql1= "insert into ost(dt,ost_number,ost_amount)values('$date','$ammount2','$reason2')";
    $sql2 = "insert into ost(dt,ost_number,ost_amount)values('$date','$ammount3','$reason3')";
    $sql3="insert into ost(dt,ost_number,ost_amount)values('$date','$ammount4','$reason4')";
 
    mysqli_query($con,$sql);
    mysqli_query($con,$sql1);
    mysqli_query($con,$sql2);
    mysqli_query($con,$sql3);
  header('location:other_source.php') ; 
}





if (isset($_POST['submit8'])) {
  $date = $_POST['date'];
  $ammount1 = $_POST['ammount1'];
    $remark1 = $_POST['remark1'];
    $ammount2 = $_POST['ammount2'];
    $remark2 = $_POST['remark2'];
    $ammount3 = $_POST['ammount3'];
    $remark3 = $_POST['remark3'];
    $ammount4 = $_POST['ammount4'];
    $remark4 = $_POST['remark4'];

    
  
  $sql = "insert into addammount(date,ammount,remark)
  values('$date','$ammount1','$remark1'),
  ('$date','$ammount2','$remark2'),
    ('$date','$ammount3','$remark3'),
      ('$date','$ammount4','$remark4')";

  mysqli_query($con,$sql);
  header('location:Additional_amt.php') ; 
}


if (isset($_POST['submit_withdraw'])) {
  $date = $_POST['date'];
  $number1 = $_POST['number1'];
    $ammount1 = $_POST['ammount1'];
    $number2 = $_POST['number2'];
    $ammount2 = $_POST['ammount2'];
    $number3 = $_POST['number3'];
    $ammount3 = $_POST['ammount3'];
    $number4 = $_POST['number4'];
    $ammount4 = $_POST['ammount4'];

  $sql = "insert into cashwithdraw(date,number,amount)
  values('$date','$number1','$ammount1'),
  ('$date','$number2','$ammount2'),
    ('$date','$number3','$ammount3'),
      ('$date','$number4','$ammount4')";

  mysqli_query($con,$sql);
  header('location:cash_withdraw.php') ; 
}

?>




