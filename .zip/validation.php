<?php 
    session_start();
    if(isset($_POST['Login']))
    { // Fetching variables of the form which travels in URL
        $username = $_POST['email'];
        $password = $_POST['psw'];
            
        if($username !=''|| $password !='' )
        { 
            define('servername','localhost');
            define('user', 'id12710932_kailash1');
            define('pass', 'kailash');
            define('dbname','id12710932_db1');
            $conn = mysqli_connect(servername,user,pass,dbname);
            if(!$conn)
            {
                die("connection failed".mysql_connect_error());
            }         
            else
            {
                $sql="SELECT `username`,`password` FROM `users` WHERE `username`='$username' and `password`='$password'";
                $result=mysqli_query($conn,$sql);
                $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
                if ($row==Null)
               {
                    echo "<script>alert('username or password not valid')</script>";
                }
                else
                {
                      // $_SESSION['VAr1'] = $username;
                        header("Location: Welcome.php");
                }
            } 
        }
    }
?>